package rpg;

public class Enemy {
	private int HP=5;
	private int strength = 10;
	private int speed = 5;
	private int defense = 5;

}
