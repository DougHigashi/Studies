package rpg;

public enum ID {
	Player(),
	Enemy();
}
