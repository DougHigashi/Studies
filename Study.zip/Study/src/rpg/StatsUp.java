package rpg;

public class StatsUp {
	
	public static void LvlUp(Player player, int x) {
		player.setStrength(x);
		
	}
	
}
