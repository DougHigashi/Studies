package studies;

public class Main {

	
	
	public static void main(String[] args) {
		Todays_attempt.upToPrimes(10);
	}
}
